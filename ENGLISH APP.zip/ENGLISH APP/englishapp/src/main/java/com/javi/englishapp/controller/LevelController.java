package com.javi.englishapp.controller;

import com.javi.englishapp.entity.Level;
import com.javi.englishapp.entity.User;
import com.javi.englishapp.repository.LevelRepository;
import com.javi.englishapp.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/level")
public class LevelController {

    private final LevelRepository levelRepository;
    private final UserRepository userRepository;

    public LevelController(LevelRepository levelRepository, UserRepository userRepository) {
        this.levelRepository = levelRepository;
        this.userRepository = userRepository;
    }

    @PostMapping("/assign/{userId}")
    public ResponseEntity<String> assignLevel(@PathVariable Long userId, @RequestBody Map<String, String> levelRequest) {
        String levelName = levelRequest.get("level");  // Obtener el nombre del nivel

        // Buscar el nivel por nombre
        Optional<Level> levelOptional = levelRepository.findByName(levelName);

        if (!levelOptional.isPresent()) {
            return ResponseEntity.badRequest().body("Level not found");
        }

        Level level = levelOptional.get();  // Aquí obtenemos el nivel del Optional

        // Buscar al usuario y asignar el nivel
        Optional<User> userOptional = userRepository.findById(userId);
        if (!userOptional.isPresent()) {
            return ResponseEntity.badRequest().body("User not found");
        }

        User user = userOptional.get();
        user.setLevel(level);
        userRepository.save(user);  // Guardar al usuario con el nivel asignado

        return ResponseEntity.ok("Level assigned successfully");
    }
}
