package com.javi.englishapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnglishappApplicationTests {

	@Test
	void contextLoads() {
	}

}
