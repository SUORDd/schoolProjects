package com.javi.englishapp.entity;

public enum Role {
    USER, ADMIN
}