package com.javi.englishapp.controller;

import com.javi.englishapp.entity.User;
import com.javi.englishapp.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import java.util.Optional;

@RestController
public class RedirectController {

    private final UserRepository userRepository;

    public RedirectController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/redirectByRole")
    public ModelAndView redirectByRole(Authentication authentication) {
        if (authentication == null) {
            return new ModelAndView("redirect:/index.html?error=unauthorized");
        }

        String username = authentication.getName();
        Optional<User> optionalUser = userRepository.findByUsername(username);

        if (optionalUser.isEmpty()) {
            return new ModelAndView("redirect:/index.html?error=user_not_found");
        }

        User user = optionalUser.get();

        // Verifica el rol del usuario y si tiene un nivel asignado
        for (GrantedAuthority authority : authentication.getAuthorities()) {
            if (authority.getAuthority().equals("ROLE_ADMIN")) {
                return new ModelAndView("redirect:/admin.html");
            } else if (authority.getAuthority().equals("ROLE_USER")) {
                if (user.getLevel() == null) {
                    // Si no tiene nivel asignado, redirigir a la página de prueba
                    return new ModelAndView("redirect:/test.html");
                } else {
                    // Si tiene nivel asignado, redirigir a la página de felicidades
                    return new ModelAndView("redirect:/felicidades.html");
                }
            }
        }

        return new ModelAndView("redirect:/index.html");
    }
}
