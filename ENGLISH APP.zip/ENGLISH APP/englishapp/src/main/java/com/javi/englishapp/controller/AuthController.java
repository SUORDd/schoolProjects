package com.javi.englishapp.controller;

import com.javi.englishapp.entity.Role;
import com.javi.englishapp.entity.User;
import com.javi.englishapp.repository.UserRepository;
import com.javi.englishapp.service.UserService;
import com.javi.englishapp.service.CustomUserDetails;  // Asegúrate de importar tu CustomUserDetails

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserService userService;
    private final UserRepository userRepository;

    // Constructor para inyectar UserService y UserRepository
    public AuthController(UserService userService, UserRepository userRepository) {
        this.userService = userService;
        this.userRepository = userRepository;
    }

    // Endpoint para obtener el usuario autenticado
    @GetMapping("/user")
    public User getAuthenticatedUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        // Obtener el CustomUserDetails, no el User directamente
        CustomUserDetails customUserDetails = (CustomUserDetails) authentication.getPrincipal();

        // Obtener el usuario asociado al CustomUserDetails
        User user = customUserDetails.getUser(); // Asegúrate de que CustomUserDetails tiene un método getUser()

        return user;
    }

    // Endpoint para registrar un nuevo usuario
    @PostMapping("/register")
    public ResponseEntity<Void> registerUser(@RequestParam String name, @RequestParam String username, 
                                             @RequestParam String password) {
        // Crear el usuario y asignar valores
        User user = new User();
        user.setName(name);
        user.setUsername(username);
        user.setPassword(password);
        user.setRole(Role.USER);  // Asignar rol predeterminado "USER"
        
        // Registrar al usuario
        userService.registerUser(user); // Llamamos al servicio para registrar el usuario
        
        // Redirigir a la página de inicio con un parámetro de éxito
        return ResponseEntity.status(HttpStatus.FOUND)
                             .header(HttpHeaders.LOCATION, "/index.html?registered=true")
                             .build();
    }

    // Endpoint para obtener el nivel del usuario autenticado
    @GetMapping("/user/level")
    public ResponseEntity<String> getUserLevel(Authentication authentication) {
        String username = authentication.getName(); // Obtener el nombre de usuario
        Optional<User> optionalUser = userRepository.findByUsername(username); // Buscar al usuario en la base de datos

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            if (user.getLevel() != null) {
                String levelMessage = "Felicidades, has alcanzado el nivel: " + user.getLevel().getName();
                return ResponseEntity.ok(levelMessage); // Devolver el mensaje con el nivel
            } else {
                return ResponseEntity.ok("Aún no tienes un nivel asignado.");
            }
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no encontrado.");
        }
    }
}
