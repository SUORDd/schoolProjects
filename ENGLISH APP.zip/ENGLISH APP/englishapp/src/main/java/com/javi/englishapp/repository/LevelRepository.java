package com.javi.englishapp.repository;

import com.javi.englishapp.entity.Level;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LevelRepository extends JpaRepository<Level, Long> {
    Optional<Level> findByName(String name);  // Cambiado para devolver Optional<Level>
}
