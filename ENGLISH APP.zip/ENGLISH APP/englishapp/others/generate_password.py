import bcrypt
password = "admin123" #cambiar
hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
print(hashed)
