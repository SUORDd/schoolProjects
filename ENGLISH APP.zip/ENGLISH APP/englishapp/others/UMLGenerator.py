import os
from graphviz import Digraph

def find_java_classes(directory):
    """Escanea el directorio en busca de clases Java y las organiza por paquetes."""
    class_map = {}

    for root, _, files in os.walk(directory):
        package_name = root.replace(directory, "").strip(os.sep).replace(os.sep, ".")
        if package_name == "":
            package_name = "root"

        class_map[package_name] = []

        for file in files:
            if file.endswith(".java"):
                class_name = file.replace(".java", "")
                class_map[package_name].append(class_name)

    return class_map

def generate_uml(class_map, output_file="uml_diagram"):
    """Genera un diagrama UML de paquetes y clases en formato PNG."""
    dot = Digraph(comment="Diagrama de Clases", format="png")

    for package, classes in class_map.items():
        with dot.subgraph(name=f"cluster_{package}") as sub:
            sub.attr(label=package)
            for class_name in classes:
                sub.node(class_name)

    dot.render(output_file)
    print(f"Diagrama UML generado: {output_file}.png")

if __name__ == "__main__":
    project_directory = "src/main"  # Cambia esto según la ubicación de tu código
    class_map = find_java_classes(project_directory)
    generate_uml(class_map)
