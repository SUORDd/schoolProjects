package com.javi.englishapp.controller;

import com.javi.englishapp.entity.User;
import com.javi.englishapp.repository.UserRepository;
import com.javi.englishapp.service.CustomUserDetails;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        return userRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @GetMapping("/user/level")
    public ResponseEntity<String> getUserLevel(Authentication authentication) {
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        User user = userDetails.getUser();
        
        if (user.getLevel() != null) {
            return ResponseEntity.ok("Felicidades, has alcanzado el nivel " + user.getLevel().getName());
        } else {
            return ResponseEntity.ok("Aún no tienes un nivel asignado.");
    }
}

}
