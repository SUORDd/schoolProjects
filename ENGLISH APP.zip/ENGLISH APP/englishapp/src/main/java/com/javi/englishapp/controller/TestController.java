package com.javi.englishapp.controller;

import com.javi.englishapp.entity.TestResult;
import com.javi.englishapp.entity.User;
import com.javi.englishapp.repository.TestResultRepository;
import com.javi.englishapp.repository.UserRepository;
import com.javi.englishapp.service.CustomUserDetails; // Si tienes un servicio para obtener los detalles del usuario
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/test")
public class TestController {

    private final TestResultRepository testResultRepository;
    private final UserRepository userRepository;

    public TestController(TestResultRepository testResultRepository, UserRepository userRepository) {
        this.testResultRepository = testResultRepository;
        this.userRepository = userRepository;
    }

    @PostMapping("/submit")
    public ResponseEntity<String> submitTest(@RequestBody Map<String, String> answers) {
        // Obtener el usuario autenticado
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails customUserDetails = (CustomUserDetails) authentication.getPrincipal();
        User user = customUserDetails.getUser(); // O utiliza un método similar para obtener el usuario

        if (user == null) {
            return ResponseEntity.badRequest().body("User not found");
        }

        // Guardar cada respuesta como un TestResult separado
        for (Map.Entry<String, String> entry : answers.entrySet()) {
            TestResult result = new TestResult();
            result.setUser(user);
            result.setQuestion(entry.getKey());
            result.setAnswer(entry.getValue());
            testResultRepository.save(result);
        }

        return ResponseEntity.ok("Test submitted successfully!");
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Map<String, String>>> getTestResults(@PathVariable Long userId) {
        List<TestResult> results = testResultRepository.findByUserId(userId);

        if (results.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        // Convertir resultados en un formato JSON esperado por el frontend
        List<Map<String, String>> response = results.stream()
            .map(result -> Map.of("question", result.getQuestion(), "answer", result.getAnswer()))
            .collect(Collectors.toList());

        return ResponseEntity.ok(response);
    }
}
