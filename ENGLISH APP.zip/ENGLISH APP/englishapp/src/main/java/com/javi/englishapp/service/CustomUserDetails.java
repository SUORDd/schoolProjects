package com.javi.englishapp.service;

import com.javi.englishapp.entity.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

public class CustomUserDetails implements UserDetails {

    private final User user;

    public CustomUserDetails(User user) {
        this.user = user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // Deberías convertir el rol en un GrantedAuthority si lo necesitas.
        // Esto es solo un ejemplo para roles.
        return List.of(() -> "ROLE_" + user.getRole().name());
    }

    @Override
    public String getPassword() {
        return user.getPassword();
    }

    @Override
    public String getUsername() {
        return user.getUsername();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;  // Lógica de expiración si es necesario
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;  // Lógica de bloqueo si es necesario
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;  // Lógica de expiración de credenciales si es necesario
    }

    @Override
    public boolean isEnabled() {
        return true;  // Lógica de habilitación si es necesario
    }

    // Métodos adicionales que podrían ser útiles:
    public User getUser() {
        return user;
    }
}
